#pragma once

#include <stdio.h>
#include <sys/time.h>

double pega_tempo(void);

void imprime_matriz(int m, int n, int** matriz);

void inicializa_matriz(int m, int n, int** matriz);

void inicializa_matriz_t(int m, int n, int** matriz);
